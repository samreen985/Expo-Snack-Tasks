import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, Switch } from 'react-native';

const RegistrationForm = () => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(false);

  const handleSubmit = () => {
    if (!fullName || !email || !password) {
      Alert.alert('Error', 'Please fill in all fields');
    } else {
      Alert.alert('Success', 'Registration successful');
      // You can send the data to your backend here
    }
  };

  const toggleSwitch = () => setIsDarkMode(previousState => !previousState);

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      padding: 20,
      backgroundColor: isDarkMode ? '#333' : '#fff',
    },
    label: {
      marginBottom: 8,
      fontSize: 16,
      fontWeight: 'bold',
      color: isDarkMode ? '#fff' : '#000',
    },
    input: {
      height: 40,
      borderColor: isDarkMode ? '#aaa' : '#ccc',
      borderWidth: 1,
      borderRadius: 5,
      marginBottom: 20,
      paddingLeft: 10,
      color: isDarkMode ? '#fff' : '#000',
      backgroundColor: isDarkMode ? '#444' : '#fff',
    },
    switchContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 20,
      justifyContent: 'flex-start',
    },
    switchLabel: {
      fontSize: 16,
      marginRight: 10,
      color: isDarkMode ? '#fff' : '#000',
    },
    formContainer: {
      marginTop: 20,
    },
  });

  return (
    <View style={styles.container}>
      {/* Mode Switch at the top */}
      <View style={styles.switchContainer}>
        <Text style={styles.switchLabel}>Dark Mode</Text> {/* Updated text here */}
        <Switch
          value={isDarkMode}
          onValueChange={toggleSwitch}
          trackColor={{ false: '#767577', true: '#81b0ff' }}
          thumbColor={isDarkMode ? '#f4f3f4' : '#f5dd4b'}
        />
      </View>

      <View style={styles.formContainer}>
        <Text style={styles.label}>Full Name</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your full name"
          value={fullName}
          onChangeText={setFullName}
          placeholderTextColor={isDarkMode ? '#ccc' : '#777'}
        />

        <Text style={styles.label}>Email Address</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your email"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          placeholderTextColor={isDarkMode ? '#ccc' : '#777'}
        />

        <Text style={styles.label}>Password</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
          placeholderTextColor={isDarkMode ? '#ccc' : '#777'}
        />

        <Button title="Submit" onPress={handleSubmit} />
      </View>
    </View>
  );
};

export default RegistrationForm;
