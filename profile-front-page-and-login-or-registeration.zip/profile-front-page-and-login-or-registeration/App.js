import React, { useState } from "react";
import { View, Text, TextInput, ImageBackground, StyleSheet, TouchableOpacity } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

const AuthScreen = () => {
  const [isLogin, setIsLogin] = useState(true); // Toggle state

  return (
    <ImageBackground
      source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTtQNulnrS1ZvKeglgihsEjHEAu8ETEh4pkCg&s" }} // Replace with your image URL
      style={styles.background}
    >
      {/* Gradient Overlay */}
      <LinearGradient colors={["rgba(255,0,150,0.6)", "rgba(255,0,150,0.4)"]} style={styles.overlay} />

      {/* Auth Form Container */}
      <View style={styles.formContainer}>
        <View style={styles.form}>
          <Text style={styles.title}>{isLogin ? "Login" : "Registration"}</Text>

          {/* Email Input */}
          <TextInput style={styles.input} placeholder="Email" placeholderTextColor="#888" keyboardType="email-address" />

          {/* Username Input (Only for Registration) */}
          {!isLogin && <TextInput style={styles.input} placeholder="Username" placeholderTextColor="#888" />}

          {/* Password Input */}
          <TextInput style={styles.input} placeholder="Password" placeholderTextColor="#888" secureTextEntry />

          {/* Confirm Password (Only for Registration) */}
          {!isLogin && <TextInput style={styles.input} placeholder="Confirm Password" placeholderTextColor="#888" secureTextEntry />}

          {/* Submit Button */}
          <TouchableOpacity style={styles.button}>
            <Text style={styles.buttonText}>{isLogin ? "Login" : "Register"}</Text>
          </TouchableOpacity>

          {/* Toggle Button */}
          <TouchableOpacity onPress={() => setIsLogin(!isLogin)}>
            <Text style={styles.toggleText}>
              {isLogin ? "Don't have an account? Register" : "Already have an account? Login"}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
};

// Styles
const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    height: "100%",
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
  },
  formContainer: {
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",
    width: "100%",
  },
  form: {
    backgroundColor: "white",
    padding: 25,
    borderRadius: 12,
    width: "85%",
    maxWidth: 400,
    alignItems: "center",
    elevation: 8,
    marginBottom: 50, // Shift form down
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 15,
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 12,
    marginBottom: 10,
    borderRadius: 6,
    backgroundColor: "#f9f9f9",
  },
  button: {
    backgroundColor: "#FF0080",
    padding: 15,
    borderRadius: 6,
    alignItems: "center",
    width: "100%",
    marginTop: 10,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
  },
  toggleText: {
    marginTop: 15,
    color: "#FF0080",
    fontWeight: "bold",
  },
});

export default AuthScreen;

