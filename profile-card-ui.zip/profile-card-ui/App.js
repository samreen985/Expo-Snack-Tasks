import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const ProfileCard = () => {
  return (
    <View style={styles.card}>
      {/* Image on the left side */}
      <Image
        source={{ uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAwwMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAEBQMGAAECBwj/xAA+EAACAQMDAgUBBgMHAwQDAAABAgMABBEFEiExQQYTIlFhcRQjMlKBkUKhsQckM2JywfAlQ9EVU9LhNHOC/8QAGQEAAwEBAQAAAAAAAAAAAAAAAgMEAQAF/8QAIxEAAgICAgEFAQEAAAAAAAAAAAECEQMhEjFBBBMiMlFhQv/aAAwDAQACEQMRAD8A8fZa0B6huBxnn6VbrCw0+O4lGpZVNpCFeue1Vq9jjWeQqTjPp4FP5fKqF8dWCsRuJAIXJx71IsrB0ZtrleFDDIx81xj261gHOCPjFECdiFmkYHClRkg1ZNL1D7N4au7ZtNikMzKRckeqPHYGkr2rt5TCNVIQAsufWfc/P/incF3eJpT2KBfKdgzZHPHSulzX1Ni4f6KsxyxOMV00ZRI3bGHyQA2enHI7UTNYyKeFY5PHGc0JtO7b3Nc012YmvBJDHuPNTo01vIs0EpjdD6WXgjIwf5GhkkML7m6DqK4mvt3pjGB+bvQt0alZokRjngY4rhplHQ5qCTJOeea4waD3H4DUf0JE4+lTxXBj5jfBpfXQyvNcsjMcEGsSx3Mck967iiaRwFXOeKGjl3eluKJSVlGFPfjFMvkDVG54mhl2Z+tRU91LSrWDQ7W/TUIpp5iQ8AJ3R49/rSLtRVQIxttRu4bN7eye4CMpa4VSdrAdCQOw+ahOo3LW/wBnMj+X1Cg8ULz7/HFarKT7CTa6GFlp+o3ds11bwTywQcFxkqnfHxQLHc5Jxz2Fdx3E8cTRxzSIjH1KrkA/pUffnOK1mHcxiZ18lWVdi5DHPqxyfpmuCKkZVIjEZZnK5cAcA/H6dfnNNPDcekSXTjW5JY4Nh2tGuTuxxXI5ifBrVM//AEi4nJktY90JJ2HcOgOKyu0dTLN4isykjjGDzxVcuHiSxa1+yxmUy7/tBHqA/KPivQ/ENkxL8Enk571SL21Ul9zhdoyAf4vii7BEkEkkE6ywuUkQ5Vx2NNJ0spI7aS2aV7lsmcP03fFBCP0su8gDkLiidPG2QZ55rHG3ZzlSLBZwedGuUANNE0+NV5ArjTMBQOM9qb3NtNBEkkyFVcZUnuKOiSU2Vy/sEK5AHFVPUIDBJlcKR3xV5unG0+xqm+JZFUCMfifP7UM3SGYZOTor80pkY5PGa6hTjcRXMaZ5PSpgxfB7dBUjdl9UcuQOgyTXAgdvU+EX3JreWL7YcknjjvUz6ddqMyxsv+qssFyiu2DMiBsJJu+cYrtMH7uXj2PtWNayDoM1r8Y2P+IfhP8AtXGppnEilH2t1FSwSZ9JrTHzIQW/HHx+lQhuQaKLpnNWH7mwQSSKkaDFskvmx+okCMH1DHv7VBGd65FSBPYfWqFsS9HP6ce1dqgCOTLtdQNqEH1f+MUXaxIQd2MjtRNtbW93f41G4kSJyxeULvbOOP54FbR1gLQ2v/p6yrcf3neQYNp/D75oWiWtyFZgBtDYPPPxxUTlmUKei5xwO/WuaOs4Vip3KSCO47Vrp9Rx1oq2iynmcUw1D7A+lxeTEUulJ8xs8EfSlt0ElYoEjgYDsPgE1lcfoayiqJlyPdtftypcqSCc8+9eearbgu27gZ64zXr2tRHy5CvTbz9K871W0QuWl6E10WY1RS5ke0uQ0Uo3gZV4znGR/wAFcQEhwe//ADii72JRO2wcfFQBCOlMQD2WHTbhmWMRxcqpyVPXvk/Sml54guL22himk3JEu1Aw6CkVtrclrBiMqXMfl+oZwKWtdEDk1qYmWP8ABxdXPoDNnaeA30qk6tObm/fbn0naKZ3d4RETu4A4FJIs+Yzt1AJ/Wk5n4H+nx8dm3GWEKfrW5eZPKiHxWRemN5T17U/8I6LJczfa57G9ubVG9YtowWP0JIFTt0ipKT6DvDGmQQDzDDJc3eOI44y+39BTS98JeJNQczJpNztP5l5x+9el+D/EfhnYtlZKunzJwYLhNjk++T1q6BlYA5B+RSe9iF6B8uc5bPmO98N6pZ5M0BQjqrDaf2NI7mBjlSu2RexGDX1tPFDcIUmiSVT1DqCDVE8X/wBm2n6vE8+l4srwD0r/ANpvjH8P1HHxRhPDOO1s+dy2Gz3PDCo2GDx0ptr+kXOl3ckF3E0csbbXBHel7R4SMjneD/KjWw07R1ZtmQJ3bpTm3t/ekCkxyg9wc1bbVgUVvzAHiqMTtCsutksNpK8TqoZ4o/WQBwucc/0omwnWykDG2hmAz/iLk9MV1azywxyRxOVWVdsgB/EPmtyRKEUiQMWGSAMbac1aJ+buxPdwbm34A3dAO1AtDlgp4yaeToMdAMDr70Nqlmts0e2aOYOgYlP4Sex+a6tBqViyVlt5WiQZUY6VDLPvG3kL3z1rcq81C3eltDEyyWN1pCWkazxZkA5NbqsVlK9n+jfd/h9N6xEWDe1efa3By2Ome9enaknBqsazDYyWKogK3Jb1s59OKODFzPLbq3Ac7c/OaG8k+1Pry2Ic9MA9aGW1LZ46U0WJJYSOgodonxmrMbHdyAMUPd2iRREvgcVxpTr5vvhH+UbjQyqdhHcmpWkFxczSAcZwv0qSNPvASOOakk7ZQlSOYbdri4jt1BI6kCrxp3izUdLsJrLTdPfNrGzzMy7do96i/sq01NR1tpZF3BDk5+DXrWu+EbbVJzdwMIp2TZJx6ZF9jSnsqxxajZ5le6odUuIodf023WQuF82CUMyEjd6scrgEDvz1r0nwRaT6bC1o91LcR7iU8w5IFA6V4IltZ2eUQSs8ZhLyFmYRnqBnv9atWnWaWlzFEDkIm3PwKBr8GXrZvWb2SztWMODNg7Qema86n8S+MvNKifTY13Ywwq668stx9peCMOyemME4Gfc15Fq+mOdUukla4ud0mYWjdlLbkwFABABD56/vXLZ2oroJ8W6frus2jX+ofYJ/LTazW5KsV68jHOK88Kfc2gP/ALjqf3FWwS6xpeoSafGzX6kKsvl+rY2OQfp0qv3UbBrcOu1vtTgj9qZHRPlhFO0KJ123DqferFo7+ZaR46r6TSa/T/qciDu1O/DdrK9vdyLGTFDIAzjopPQfyp+J/Imyr4jWNOATnkdKnKp5YPmevJyu3oOxzXRJKjPaopD15Az3NVEYPMRgDj3+aAmwcgLkk8Y96ZeXLNDtjTcqkncBz+9Kbg43Kay09DFFrYJcI0cjRyrtdSQy9wQcEUI3WmWoWM1pHbyThQlzH5keGydpJHPseKAmVVldUdZFBwHUEBvkA8/vQsYiLFZXQHFZWHH1bfpnPGfiqpqkJCOgA2nBq6XKcGq/qcOd1IgxkkUK9t/XXcemweRI7S7XH4F/NTS7tfWeKhW3YnB6U2xYu+z4Xnr3qr+NJ/senFQcSTHYv0716Abb04wa8l/tBuxNrhtlIK2q7OPzHk1k5aCgtiW2G2It7t/tRMS5V/8ATQ8fEC/v+9GWI3Syp/kNTjmX7+xY7Lm6HcAGvaIW4rwb+yS8S28R/Z5Gx9ohIXP5l5/pn9q9ziYdzQWVYp3BBm4BST7VBaHzZpJOyitkB42UnAIxnNJJY763kaKKZnLjIbt+uKCTGKLY0sxuLk9yTUN7o2n3jbp7aIn82Oa3pscyRsZipJ/L2olpQF61sao5diyPRNO09He3hSI46qOtfPd+Vk1VUj5UXcrfzr3fxXq8em6RcTM3OwgDPc8V4BZE+e0rc+TGxJ/zMaNCc76j5Abk79Wf4am3h1mF1eJuO0hSRng4JpPafeXcr+wzTPw63/U5l7GP/f8A+6bj+yJMn1ZZCa4SRIZ4ZJFSZAQxi555/CeO9YxoOc5PFWEQxttfazjuhDDGonyOmdi+wzVduZRIpbbhvf3qWQ9cUPMgVVYOrbs5UHkfWgUUnaH8m1TBWIcAyFgoyMgZx/OoCPV3/WrFok8aFQBAz7WG2ZgBn6mk0cam8Ik/AWJIHQVy2zfBGiZUGsr0BdM8KbE2XlyQUUn7rvjn+ea1RUZZ71OmQaTXsG7PHFP3XNAzwg5qOLHtFVuLPLdK4jssHp+9PZYF3VHJ5VujSSfhUbj9BR8geJXNX1DTNHjVtSvIIGYFkjZvU+PYdTXz1qdwbzUri5bP30rNz8nirHq9zcaxqF9q053lnyATwEB9IHxikuswJHrM6RIUi3goD7EZpXK2ZjkpNpERG1VX6A1Jby+XdjJxlailOCvzzUV02ybI64FcNG+nyzWN6Lm3OLi0m8yPHfvj9RkV9AeHdat9Z02G6gZSJFyVB6HuK+e4pA0dvdHhX+5lPsexp34Z1668PXrPGN1qW+9iHb/MKVJGY8qxyqXTPZdesHYCdbm5QD8arJ6friq/5d9Gf7pqbbOuDnP8qtWg61p+s2STwSq6SDpnv7VJNodizCRTsPU/NAexh9QoKmhdot9rDlYryJJIQP8AHDcj9KbXU4SIkkDA5JoS+vbTS7ZnlljijQcsxxgV5j4t8XPqCC2thIts/Rc7WmHz7L/WuRHnzxh8qBPHniL7fMyQyZs48rHjpK/dvoOg+c1TZH+z6a+ThpcCt3jGacLkHGN2Ogx0A+BQOoS73WJTwKdFEUZOb5sn05MWdxMeOgFE+Hz/ANUl/wD1f7iucCLS0UfxNzXdgPJ0+W4Vl86S5WNT3UKMn9yR+1Mi6dnT+rLG3I4/eoAzR52Y5GDkVvT7oTx7mX1jhl+fepXTczcce46VYmmrIhc8ff8AlQ8kfxTXysnFaubJoX2vtJKhvS2RyM1pqYjMZB9Jwa6igct0P1o94PYUetz/AHCOyWJdqtuL7Ruz9fagdroYmjLaH7hOe1ZRsC/dKMHgVlGByPow8UPNg5xzU0rhTzSW/wBT+zbyDXnl3ZBf3ccKkk4Nef8AjfxQbXTpVgOZZRsXnpnipPEuu8thq8x1y+a7njDMSFJP0or0Bk1EktZorcRxScxSx7H+M0NqdoZot4P94tECMCfxxdFYf6eBQVxIx4U9OlG2V400Cx79lzBzE+eo7qfek9MkgnjfJCW74uAgyMDvUN0cyZ+BTW/s1uka+s4lj2f/AJFshP3f+cf5f6UpuB95+gpqLE72gvTpQ6SWsn+HKOvsexouC4eOUCQcoNkg9xSVWKsCOCKYSS+aizr+IcP8isaByQ5IsFlfXOl3RexnERfnB/A496dz+PtfgHlSRRqVGMkmqlZuLmD7Ocb/AMURJ7+1SQSlwq3B3RxjgH+n0pRPHNkgqsY3mp3l2ovtXnaaV+YLfog/zEf0zSy+uGgV/MYtcvzI57fFdxyySXDXUnql/gz0B7ftSuaQSzZLExockn+I+9akdFPJK2bZ/Ihz/G3JoKL1Sj61lxKZXz27VuDqx9qbRWMLmTMaRrnpwPc0/fTZLbSYo34FuS8gB/FI2M/sNo/SgNKgFvHHdS83Eo/uyY/wxn/EOf5foabXUjTqtrGSc8uc9ffNLm/CI/VZWqihfpEo+1Mj/wDcXA+WFWCMbVdCiHfxuYZKc9qqdyfJuMxnBQgj9KtMVzHJECMHeoNVYJWqBW1YRcRwgjy2ZgByWGOaiaBiM7Tz7CtxsMYp7bajaLpD2z2qtOzZEvcfFUWdRWzBnoM1tLf1DimMaAk5HfpRUNurGNcbccE+/wA1oL0QxW/3Y4rKdR28QQA5J+lZXGWeo6rciOFpBxjivNfEesFdwDmrD4ovzDETkjIwPY15Nrd+Xkb1HrXnnqpAWs6g0rn10hdi7FietdXMu5mJNS+Qr2NtcQ9JFKuAc7ZFOCPjI2t+vxWy6E5ugRqiyUcOpPBqYjnn9q35RZSUHTrQE6ZMk7CRbi2cxyjqR/zkVzqFpFeRPeWabHjAM9uo4UfnX/L7jt9KHjJRuDxU0UskMgmgYqy9Pn3/AE+K5aCjJxE2OTU9o4WTY34X4NNJNPh1Hc9igiuQu5rbPD+5T/4/tSXpyP0ox6dhsDtDPsBwy/hPzTN7jB8yNI/XzgqDg/GaUXJ3LHMvcc/FEQTBoyM0LQnLC9nd1eSlNuR6uMKoH9KXynYBGD9amZ+TJ0HRaFPOSa1IZjjxRnWm2lWKC2N/e5+yI4CqMbpm/KP5En2qLTtOEkRurtvKtVOAT1lb8qj9uaKuLh7qUM42xxjbFGOka+w/3965s6UkiRbmR5nuJSd7HgDovsB8Cm1mRBaPJIfW4yfgUkt/vJBu/CtMVZrlygOEXljSpEGZOQBdHfIznpTO03W8EKycFkDj6GgYYTeX3lghYwcu/wCVR1P/AD4qS4vDc3UkwXYrn0r+UdAP0AFOxOnZTjhocxTD3oyOXOPVSGGbA5PFHxSuqB2BCngHsTVCmG4D+1HmOq7gpPc9KaWiNI2yMbm+B1qu2c5kdUXliQAKdWUuMdqNSsROFDwC12rteTGB1A6963QyuCordGKAfF+qSSZi3+lc4GeBXnepyjz3CtvXcdrYxuHvjt9KsHiO5zI9U+5fLMahPWA7mQheKL8PXS+a1lM+2KdgVP5ZB+E/TnB+tLLo+vb7VEK57FyV6LFf2hjdmClWU4lj7q3/AIoOOQhgyn1CiNN1ESoYtRcggYjuCc4+G9x/StX1nJbOrDG1xlGU5Vv9J70D0SuDXZKmnXF/Kn2CBppJMny0HOQMn+QNZomm3usXIh0y3adl5bsqg+57Vbv7ILaS51i7nORFFAYyewLdf1wMf/1V98OWcMd80NnbpDArmSTauN7Z4zWFOH0zlH5HkOt+H7/SrjyriMQXUY37VbJ47gjvSy8hXVInuoQftyLm4iC/4nvIP9x+tXj+01b211+PVGjf7FLmNJP4WI6iqrqlq0Ih1bTHZOQ2UPKNXcqYhy9rJwfRXYTviaPt1FRDKkqCabXEMdzbvqFsoSZD/eoQff8AjUY4UnqOxoGaPlWUZJ6YphQQMdxCA8Cm+n6db29ut7qsbENnyLbODKfdvZf61PDYxaUiXF2iyXjqrJEfwxAjjcPzfHbvQlxPLdTNLM5d26k0LYuU60jdxPNdSAzEAINqIvCovYAdhUbZGAv61s8VznHTqa4VdkqkjESdTTUQvHBHaQIXubjsByB/z9qD06Iq6uULyscRoOpNS3161iksMcyvfz5W4kT/ALSf+2p+epI9sUFWwFDnKvCIr26W2VrCxIaItiebHMxB4H+kHp79aEVuaHYegYrtX9IP6U1aLEg1ZOOanW5JAySOelLg9SO6AgRktgDLYI5IBIx8HIz3xmtsKhxbXRVgQ2DT/T7skjJ71ToBIwLouQKa2sssSqZFwDzmmRYmcS8x3HoFZVfTUF2D1VlM5E3AUa5IxnfJquzHccn6VuspB6LFkhzIa5HUVlZQiyd+IgB0zROn6nc2n3KFXgcjdFIMqef5fUVlZXHHuXgO0t9P8MXdzaRCOSU7jyTyR88098LxqsLkZy5yT+uKysoEWY/oCeN9HtdT8DMtx5g+zRy3MZQ4IdVyM+4rxnw1K03m2knqgkU5U1lZQz6PL9d0AaPmHxJbxIxCSSeW491bII/Y0X4fVY7CW+CKZ4nWOMsMhM55A9/mt1lb4Ct+2hbcSPLM7SMWO49a5FarKJCjGrcIDMMjv/tmtVlYzUF39zJZabbtbnY92jCRx1ChiNo9ge/c0lhrKytiUQ6Ch0NcJxkdqysogjruKKlhWKWMLn1KCcmt1laGTxTyRLhCME068Q6xcXthYRSRwIsEQRfLTaSPn3rKymR6Al2IxcSjjcaysrKwE//Z' }} // New profile picture
        style={styles.image}
      />
      <View style={styles.textContainer}>
        {/* Updated name to Samreen Habib */}
        <Text style={styles.name}>Samreen Habib</Text>
        <Text style={styles.bio}>Software Engineer | Web Developer</Text>
        <Text style={styles.info}>
          Passionate about designing intuitive user experiences, specializing in front-end development,back-end development , Figma, and React Native.
        </Text>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Follow</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',  // Make sure the image is on the left and text is on the right
    alignItems: 'center',
    backgroundColor: '#e0f7fa', // Light teal background color for fresh look
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
    margin: 20,
  },
  textContainer: {
    flex: 1,
    paddingLeft: 10,  // Padding adjusted to give space between text and image
  },
  name: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#00695c', // Dark teal for the name
  },
  bio: {
    fontSize: 16,
    color: '#004d40', // Darker teal for bio text
    marginVertical: 4,
    fontWeight: '600',
  },
  info: {
    fontSize: 14,
    color: '#004d40', // Slightly darker grayish-teal for additional info
    marginBottom: 8,
  },
  button: {
    backgroundColor: '#00796b', // Teal color for the button
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginTop: 8,
    shadowColor: '#004d40',
    shadowOpacity: 0.4,
    shadowRadius: 5,
    elevation: 3,
  },
  buttonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: '#004d40', // Darker border color around image
  },
});

export default ProfileCard;

     