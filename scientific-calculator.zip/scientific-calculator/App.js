import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function App() {
  const [input, setInput] = useState('');

  // Handle button press to add value to input
  const handlePress = (value) => {
    setInput(input + value);
  };

  // Clear the input
  const handleClear = () => {
    setInput('');
  };

  // Backspace to remove the last character
  const handleBackspace = () => {
    setInput(input.slice(0, -1));
  };

  // Calculate the result of the input expression
  const handleCalculate = () => {
    try {
      // Replacing `^` with `**` for exponentiation in JS
      const sanitizedInput = input
        .replace('^', '**')
        .replace('ln', 'Math.log')
        .replace('sqrt', 'Math.sqrt')
        .replace('abs', 'Math.abs')
        .replace('round', 'Math.round')
        .replace('pi', 'Math.PI')
        .replace('exp', 'Math.exp')
        .replace('log', 'Math.log10')
        .replace('sin', 'Math.sin')
        .replace('cos', 'Math.cos')
        .replace('tan', 'Math.tan')
        .replace('e', 'Math.E');

      // Evaluating the expression safely using JavaScript's eval function
      const result = eval(sanitizedInput);

      if (result === undefined || isNaN(result)) {
        setInput('Error');
      } else {
        setInput(result.toString());
      }
    } catch (error) {
      setInput('Error');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.result}>{input}</Text>

      {/* First Row: Scientific Functions */}
      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('sin(')} style={styles.button}><Text style={styles.buttonText}>sin</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('cos(')} style={styles.button}><Text style={styles.buttonText}>cos</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('tan(')} style={styles.button}><Text style={styles.buttonText}>tan</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('log(')} style={styles.button}><Text style={styles.buttonText}>log</Text></TouchableOpacity>
      </View>

      {/* Second Row: Numbers and Basic Operators */}
      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('7')} style={styles.button}><Text style={styles.buttonText}>7</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('8')} style={styles.button}><Text style={styles.buttonText}>8</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('9')} style={styles.button}><Text style={styles.buttonText}>9</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('+')} style={styles.button}><Text style={styles.buttonText}>+</Text></TouchableOpacity>
      </View>

      {/* Third Row: More Numbers */}
      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('4')} style={styles.button}><Text style={styles.buttonText}>4</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('5')} style={styles.button}><Text style={styles.buttonText}>5</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('6')} style={styles.button}><Text style={styles.buttonText}>6</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('-')} style={styles.button}><Text style={styles.buttonText}>-</Text></TouchableOpacity>
      </View>

      {/* Fourth Row: More Functions */}
      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('1')} style={styles.button}><Text style={styles.buttonText}>1</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('2')} style={styles.button}><Text style={styles.buttonText}>2</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('3')} style={styles.button}><Text style={styles.buttonText}>3</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('*')} style={styles.button}><Text style={styles.buttonText}>*</Text></TouchableOpacity>
      </View>

      {/* Fifth Row: Parentheses, Delete, and Exponentiation */}
      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('(')} style={styles.button}><Text style={styles.buttonText}>(</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('0')} style={styles.button}><Text style={styles.buttonText}>0</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress(')')} style={styles.button}><Text style={styles.buttonText}>)</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('^')} style={styles.button}><Text style={styles.buttonText}>^</Text></TouchableOpacity>
      </View>

      {/* Sixth Row: More Scientific Functions and Calculate */}
      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('sqrt(')} style={styles.button}><Text style={styles.buttonText}>√</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('pi')} style={styles.button}><Text style={styles.buttonText}>π</Text></TouchableOpacity>
        <TouchableOpacity onPress={handleClear} style={styles.button}><Text style={styles.buttonText}>C</Text></TouchableOpacity>
        <TouchableOpacity onPress={handleCalculate} style={styles.button}><Text style={styles.buttonText}>=</Text></TouchableOpacity>
      </View>

      {/* Seventh Row: Additional Scientific Functions */}
      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('ln(')} style={styles.button}><Text style={styles.buttonText}>ln</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('abs(')} style={styles.button}><Text style={styles.buttonText}>abs</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('round(')} style={styles.button}><Text style={styles.buttonText}>round</Text></TouchableOpacity>
        <TouchableOpacity onPress={handleBackspace} style={styles.button}><Text style={styles.buttonText}>←</Text></TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 10,
  },
  result: {
    fontSize: 36,
    marginBottom: 20,
    fontWeight: 'bold',
    width: '100%',
    textAlign: 'right',
    padding: 10,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 30,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  button: {
    width: 70,
    height: 70,
    margin: 5,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 50,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
});