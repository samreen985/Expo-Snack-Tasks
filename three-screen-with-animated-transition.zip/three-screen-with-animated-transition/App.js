import React, { useState } from "react";
import { View, Text, Dimensions, TouchableOpacity } from "react-native";
import Animated, { useSharedValue, useAnimatedStyle, withTiming } from "react-native-reanimated";

const { width } = Dimensions.get("window");

const slides = [
  {
    id: 1,
    icon: "📱",
    title: "Welcome to Our App",
    description: "Discover new features and enhance your experience!",
    buttonText: "Next"
  },
  {
    id: 2,
    icon: "🚀",
    title: "Fast & Reliable",
    description: "Our app is optimized for speed and efficiency.",
    buttonText: "Next"
  },
  {
    id: 3,
    icon: "🎉",
    title: "Get Started Now",
    description: "Sign up and enjoy the amazing features we offer!",
    buttonText: "Get Started"
  }
];

export default function OnboardingScreen() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const translateX = useSharedValue(0);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ translateX: withTiming(-currentIndex * width, { duration: 1000 }) }]
    };
  });

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#282c34" }}>
      <Animated.View style={[{ flexDirection: "row", width: width * slides.length }, animatedStyle]}>
        {slides.map((item, index) => (
          <View key={index} style={{ width, alignItems: "center", justifyContent: "center", padding: 20 }}>
            <Text style={{ fontSize: 50, color: "#61dafb" }}>{item.icon}</Text>
            <Text style={{ fontSize: 24, fontWeight: "bold", marginVertical: 10, color: "#ffffff" }}>{item.title}</Text>
            <Text style={{ fontSize: 16, textAlign: "center", color: "lightgray" }}>{item.description}</Text>
            <TouchableOpacity
              onPress={handleNext}
              style={{ marginTop: 20, backgroundColor: "#61dafb", padding: 15, borderRadius: 10 }}
            >
              <Text style={{ color: "#282c34", fontWeight: "bold" }}>{item.buttonText}</Text>
            </TouchableOpacity>
          </View>
        ))}
      </Animated.View>
    </View>
  );
}

