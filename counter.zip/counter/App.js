import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function App() {
  const [counter, setCounter] = useState(0);

  // Increment function
  const increment = () => {
    setCounter(counter + 1);
  };

  // Decrement function
  const decrement = () => {
    setCounter(counter - 1);
  };

  // Reset function
  const reset = () => {
    setCounter(0);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.counterText}>Counter: {counter}</Text>

      <View style={styles.buttonContainer}>
        <Button title="Increment" onPress={increment} />
        <Button title="Decrement" onPress={decrement} />
        <Button title="Reset" onPress={reset} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  counterText: {
    fontSize: 30,
    marginBottom: 20,
  },
  buttonContainer: {
    marginTop: 20,
    width: '80%',
    justifyContent: 'space-around',
    height: 150,
  },
});