import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button, FlatList, TouchableOpacity } from 'react-native';

export default function App() {
  // States for task input, time input, tasks array, and display toggle
  const [task, setTask] = useState('');
  const [time, setTime] = useState('');
  const [tasks, setTasks] = useState([]);
  const [showTasks, setShowTasks] = useState(false);

  // Function to add a new task
  const addTask = () => {
    if (task.trim() && time.trim()) {
      const newTask = {
        id: Date.now().toString(), // Unique id for each task
        task,
        time,
        completed: false, // Initially set task as not completed
      };
      setTasks([...tasks, newTask]);
      setTask('');
      setTime('');
    }
  };

  // Function to toggle task list display
  const displayTask = () => {
    setShowTasks(!showTasks);
  };

  // Function to remove the last added task
  const removeTask = () => {
    if (tasks.length > 0) {
      setTasks(tasks.slice(0, tasks.length - 1));
    }
  };

  // Function to mark task as completed and show green checkmark in box
  const completeTask = (taskId) => {
    setTasks(tasks.map(task =>
      task.id === taskId ? { ...task, completed: true } : task
    ));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Task Manager</Text>
      
      {/* Input for Task */}
      <TextInput
        style={styles.input}
        placeholder="Enter task"
        value={task}
        onChangeText={setTask}
      />
      
      {/* Input for Time */}
      <TextInput
        style={styles.input}
        placeholder="Enter time"
        value={time}
        onChangeText={setTime}
      />
      
      {/* Add Task Button */}
      <View style={styles.buttonContainer}>
        <Button title="Add Task" onPress={addTask} />
      </View>
      
      {/* Display Task Button */}
      <View style={styles.buttonContainer}>
        <Button title="Display Task" onPress={displayTask} />
      </View>
      
      {/* Remove Task Button */}
      <View style={styles.buttonContainer}>
        <Button title="Remove Task" onPress={removeTask} />
      </View>

      {/* Displaying the list of tasks */}
      {showTasks && (
        <FlatList
          style={{ marginTop: 20 }}
          data={tasks}
          keyExtractor={item => item.id}
          renderItem={({ item, index }) => (
            <View style={styles.taskItem}>
              {item.completed ? (
                <View style={styles.checkmarkBox}>
                  <Text style={styles.checkmark}>✔️</Text>
                </View>
              ) : (
                <TouchableOpacity onPress={() => completeTask(item.id)}>
                  <Text>
                    {index + 1}. {item.task} at {item.time}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    marginTop: 50,
  },
  title: {
    fontSize: 24,
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#777',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  buttonContainer: {
    marginVertical: 5,
  },
  taskItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  checkmarkBox: {
    width: 40,
    height: 40,
    borderWidth: 2,
    borderColor: 'green',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#e0f7e0', // light green background
  },
  checkmark: {
    color: 'green',
    fontSize: 20,
    fontWeight: 'bold',
  },
});