import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity } from 'react-native';

export default function App() {
  const [input, setInput] = useState('');

  const handlePress = (value) => {
    setInput(input + value);
  };

  const handleClear = () => {
    setInput('');
  };

  const handleCalculate = () => {
    try {
      setInput(eval(input).toString());
    } catch {
      setInput('Error');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.result}>{input}</Text>

      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('1')} style={styles.button}><Text style={styles.buttonText}>1</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('2')} style={styles.button}><Text style={styles.buttonText}>2</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('3')} style={styles.button}><Text style={styles.buttonText}>3</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('+')} style={styles.button}><Text style={styles.buttonText}>+</Text></TouchableOpacity>
      </View>

      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('4')} style={styles.button}><Text style={styles.buttonText}>4</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('5')} style={styles.button}><Text style={styles.buttonText}>5</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('6')} style={styles.button}><Text style={styles.buttonText}>6</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('-')} style={styles.button}><Text style={styles.buttonText}>-</Text></TouchableOpacity>
      </View>

      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('7')} style={styles.button}><Text style={styles.buttonText}>7</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('8')} style={styles.button}><Text style={styles.buttonText}>8</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('9')} style={styles.button}><Text style={styles.buttonText}>9</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('*')} style={styles.button}><Text style={styles.buttonText}>*</Text></TouchableOpacity>
      </View>

      <View style={styles.buttonRow}>
        <TouchableOpacity onPress={() => handlePress('0')} style={styles.button}><Text style={styles.buttonText}>0</Text></TouchableOpacity>
        <TouchableOpacity onPress={handleClear} style={styles.button}><Text style={styles.buttonText}>C</Text></TouchableOpacity>
        <TouchableOpacity onPress={handleCalculate} style={styles.button}><Text style={styles.buttonText}>=</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('/')} style={styles.button}><Text style={styles.buttonText}>/</Text></TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  result: {
    fontSize: 48,
    marginBottom: 20,
    fontWeight: 'bold',
    width: '80%',
    textAlign: 'right',
    padding: 10,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 30,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  button: {
    width: 70,
    height: 70,
    margin: 5,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 50,
  },
  buttonText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
});